<?php

/**
 * Change this token with your bot token. You can get it from @botfather (https://t.me/botfather)
 * also change this chat_id with your chat_id. To get your chat_id, you can
 * use @id_chat_bot (https://t.me/id_chat_bot) in telegram. DONT FORGET TO START THE BOT.   
 */
$config = [
    'telegram_bot_token' => '6702699920:AAEtvhHWYKGpJ3WUDXb985hjUhy3YNwUcX0',
    'chat_id'            => 6228364175
];